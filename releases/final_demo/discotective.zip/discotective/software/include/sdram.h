#ifndef __SDRAM_H_
#define __SDRAM_H_

#include <stdint.h>

extern volatile uint8_t* SDRAM_ptr;
extern volatile uint16_t* SDRAM16_ptr;

#endif
